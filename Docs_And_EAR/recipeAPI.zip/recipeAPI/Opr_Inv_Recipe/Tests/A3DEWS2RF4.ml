<?xml version="1.0" encoding="ASCII"?>
<emulation:BWTFile xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:emulation="http:///emulation.ecore"/>
